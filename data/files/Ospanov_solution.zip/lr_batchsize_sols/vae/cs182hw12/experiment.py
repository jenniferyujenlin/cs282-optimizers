import argparse
import numpy as np
import torch
import tqdm
import utils as ut
from models import vae
from train import Trainer
from pprint import pprint
from torchvision import datasets, transforms
import os




def build_config_from_args(is_jupyter=False):
    parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('--model', type=str, default='vae', choices=['vae', 'gan'])
    parser.add_argument('--num_latents', type=int, default=64, help="Number of latent dimensions")
    parser.add_argument('--iter_max', type=int, default=10000, help="Number of training iterations")
    parser.add_argument('--iter_save', type=int, default=500, help="Save model every n iterations")
    parser.add_argument('--runid', type=int, default=0, help="Run ID. In case you want to run replicates")
    parser.add_argument('--train', type=int, default=1, help="Flag for training")
    parser.add_argument('--out_dir', type=str, default="results", help="Flag for output logging")
    parser.add_argument('--batch_size', type=int, default=100, help="Batch size for training")
    parser.add_argument('--scaling_rule', type=str, default='linear', choices=['linear', 'sqrt'], help="Learning rate scaling rule: 'linear' or 'sqrt'")
    if is_jupyter:
        args = parser.parse_args(args=[])
    else:
        args = parser.parse_args()
    return args


def get_model_name(layout):
    model_name = '_'.join([t.format(v) for (t, v) in layout])
    print('Model name:', model_name)
    return model_name

def build_model(config, name=None, device='cpu'):
    if config.model == 'vae':
        model = vae.VAE(z_dim=config.num_latents, name=name)
    elif config.model == 'gan':
        model = gan.GAN(z_dim=config.num_latents, name=name)
    else:
        raise NotImplementedError
    return model.to(device)


def build_optimizers(model, config):
    if config.model == 'vae':
        opt = torch.optim.Adam(model.parameters(), lr=1e-3)
        optimizers = [opt]
    elif config.model == 'gan':
        g_opt = torch.optim.Adam(model.g.parameters(), lr=1e-3)
        d_opt = torch.optim.Adam(model.d.parameters(), lr=1e-3)
        optimizers = [g_opt, d_opt]
    return optimizers


def experiment(config=None):
    # breakpoint()
    layout = [
        ('model={:s}', config.model),
        ('z={:02d}',  config.num_latents),
        ('bs={:03d}', config.batch_size),
        ('scale={:s}', config.scaling_rule),
        ('run={:04d}', config.runid)
    ]
    model_name = get_model_name(layout)
    pprint(vars(config))
    

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    train_loader, labeled_subset, _ = ut.get_mnist_data(device, use_test_subset=True, batch_size=config.batch_size)
    model = build_model(config, model_name, device)
    optimizers = build_optimizers(model, config)

    ################################################################################
    # TODO: Modify/complete the code here
    # Apply learning rate scaling based on batch size.
    # Get the current batch size from train_loader.batch_size
    # Use a base batch size (e.g., 100) and base learning rate (e.g., 1e-3)
    # Call ut.scale_learning_rate_with_batch_size to compute scaled LR
    # Update optimizer learning rates using param_groups
    ################################################################################
    base_batch_size = 100
    base_lr = 1e-3
    current_batch_size = train_loader.batch_size
    
    # Scale learning rate based on batch size
    scaled_lr = ut.scale_learning_rate_with_batch_size(
        base_lr=base_lr,
        base_batch_size=base_batch_size,
        current_batch_size=current_batch_size,
        scaling_rule=config.scaling_rule
    )
    
    # Update optimizer learning rates
    for optimizer in optimizers:
        for param_group in optimizer.param_groups:
            param_group['lr'] = scaled_lr
    ################################################################################
    # End of code modification
    ################################################################################

    try:
        os.mkdir(config.out_dir)
    except FileExistsError:
        pass


    writer = ut.prepare_writer(model_name, overwrite_existing=True)
    trainer = Trainer(model, optimizers,
                        writer=writer, device=device,
                        iter_max=config.iter_max,
                        iter_save=config.iter_save,
                        num_latents=config.num_latents,
                        out_dir=config.out_dir)

    trainer.train(train_loader)
    # breakpoint()

    trainer.evaluate(labeled_subset)


if __name__ == '__main__':
    config = build_config_from_args()
    experiment(config=config)